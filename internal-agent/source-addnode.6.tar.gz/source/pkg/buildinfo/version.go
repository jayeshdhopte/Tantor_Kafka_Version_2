package buildinfo

// Candidate built from this repository; deliberately not labeled as prod.19.
const Version = "1.0.0-prod.17-dataservices.4-configchange.10-rollingrestart.1-addnode.6"
